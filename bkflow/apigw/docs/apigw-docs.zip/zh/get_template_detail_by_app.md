### 资源描述

通过 bk_app_code 权限校验获取流程详情

此接口用于绑定了 bk_app_code 的流程，请求方的 bk_app_code 需要与流程模板绑定的 bk_app_code 一致才能访问。

**注意：此接口需要用户认证。**

### 输入通用参数说明
| 参数名称          | 参数类型   | 必须 | 参数说明                                                       |
|---------------|--------|----|------------------------------------------------------------|
| bk_app_code   | string | 是  | 应用ID(app id)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取     |
| bk_app_secret | string | 是  | 安全秘钥(app secret)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取 |
| bk_username   | string | 是  | 用户名，用于用户认证                                                 |

### 接口参数

| 字段              | 类型     | 必选 | 描述                                                                                                                                           |
|-----------------|--------|----|----------------------------------------------------------------------------------------------------------------------------------------------|
| with_mock_data  | bool   | 否  | 是否一起返回 mock 数据，默认为 false。 当设置为 true 时，返回数据中会增加 appoint_node_ids 和 mock_data 两个字段，且如果 appoint_node_ids 有指定 mock 执行节点时，pipeline_tree 会进行对应的精简。 |
| format          | string | 否  | 返回数据格式，可选值：raw（默认，原始格式）、pipeline_tree（流程树格式，与raw相同）、plugin（插件格式）。当传入 plugin 时，返回插件格式的数据结构。 |


路径参数:

| 字段      | 类型     | 必选 | 描述                                              |
|---------|--------|----|-------------------------------------------------|
| template_id | int | 是  | 模板 ID |

### 权限说明

- 模板必须绑定了 bk_app_code（创建模板时通过 bind_app_code 参数指定）
- 请求方的 bk_app_code 必须与模板绑定的 bk_app_code 一致
- 需要用户认证

### 返回结果示例

```json
{
    "result": true,
    "data": {
        "id": 3,
        "space_id": 2,
        "name": "测试模板",
        "desc": null,
        "notify_config": {},
        "scope_type": null,
        "scope_value": null,
        "bk_app_code": "your_app_code",
        "pipeline_tree": {
            "id": "p92c20c7854104dd3975f46a1d8664417",
            "start_event": {
                "incoming": "",
                "outgoing": "f06a78d1dcbe64fb79136b07eb7e71309",
                "type": "EmptyStartEvent",
                "id": "ec628b28ea1c74e11b92b6be3bdc0e1b6",
                "name": null
            },
            "end_event": {
                "incoming": [
                    "f5b91a6141a504b1b86f932d7e6c021f0"
                ],
                "outgoing": "",
                "type": "EmptyEndEvent",
                "id": "e7533e78a1a724b51942fcdf63fa23a60",
                "name": null
            },
            "activities": {},
            "gateways": {},
            "flows": {},
            "data": {
                "inputs": {},
                "outputs": []
            }
        },
        "source": null,
        "version": "",
        "is_enabled": true,
        "extra_info": {}
    },
    "code": 0,
    "trace_id": "xxxxxxxxx"
}
```

### 错误返回示例

模板未绑定 bk_app_code:
```json
{
    "result": false,
    "message": "Template is not bindedto any bk_app_code. template_id=3"
}
```

bk_app_code 不匹配:
```json
{
    "result": false,
    "message": "The current application does not have permission to operate this template, app=other_app, template bindedapp=your_app"
}
```

### 返回结果参数说明

| 字段      | 类型     | 描述                    |
|---------|--------|-----------------------|
| result  | bool   | 返回结果，true为成功，false为失败 |
| code    | int    | 返回码，0表示成功，其他值表示失败     |
| message | string | 错误信息                  |
| data    | dict   | 返回数据                  |

### data 包含字段说明

| 字段               | 类型       | 描述                                                             |
|------------------|----------|----------------------------------------------------------------|
| id               | int      | 流程 ID                                                          |
| space_id         | int      | 流程对应的空间 ID                                                     |
| name             | string   | 流程名称                                                           |
| desc             | string   | 流程描述                                                           |
| notify_config    | dict     | 流程通知配置                                                         |
| scope_type       | string   | 流程所属作用域类型                                                       |
| scope_value      | string   | 流程所属作用域值                                                        |
| bk_app_code      | string   | 绑定的蓝鲸应用编码                                                       |
| pipeline_tree    | dict     | 流程树，当 with_mock_data 传参为 true 时，为精简后的流程树 ｜                     |
| source           | string   | 流程来源，第三方系统对应的资源 ID ｜                                           |
| version          | string   | 流程版本号，对应第三方系统对应的资源版本 ｜                                         |
| is_enabled       | bool     | 是否启用                                                           |
| extra_info       | dict     | 额外信息                                                           |
| creator          | string   | 流程创建人                                                          |
| create_at        | datetime | 创建时间                                                           |
| updated_by       | string   | 流程更新人                                                          |
| update_at        | datetime | 更新时间                                                           |
| appoint_node_ids | list     | 当 with_mock_data 传参为 true 时返回，mock 执行时选中的节点 ID 列表              |
| mock_data        | list     | 当 with_mock_data 传参为 true 时返回，每个元素包含 node_id，data 和 is_default |

### format=plugin 时的返回示例

当 format 参数传入 plugin 时，返回插件格式的数据结构：

```json
{
    "result": true,
    "data": {
        "desc": "插件描述信息",
        "version": "0.0.1",
        "enable_plugin_callback": true,
        "inputs": {
            "type": "object",
            "properties": {
                "param1": {
                    "title": "参数1",
                    "type": "string"
                }
            },
            "required": ["param1"],
            "definitions": {}
        },
        "outputs": {
            "type": "object",
            "properties": {
                "output1": {
                    "title": "输出1",
                    "type": "string"
                }
            },
            "required": ["output1"],
            "definitions": {}
        },
        "context_inputs": {
            "type": "object",
            "properties": {
                "executor": {
                    "title": "任务执行人",
                    "type": "string"
                }
            },
            "required": ["executor"],
            "definitions": {}
        },
        "forms": {
            "renderform": "(function () { ... })();"
        },
        "app": {
            "url": "http://example.com/",
            "urls": ["http://example.com/"],
            "name": "示例应用",
            "code": "example-app"
        }
    },
    "code": 0,
    "trace_id": "xxxxxxxxx"
}
```

### format=plugin 时 data 字段说明

| 字段                   | 类型     | 描述                                        |
|----------------------|--------|-------------------------------------------|
| desc                 | string | 插件描述信息                                    |
| version              | string | 插件版本号                                     |
| enable_plugin_callback | bool   | 是否启用插件回调                                  |
| inputs               | object | 插件输入参数 JSON Schema                       |
| outputs              | object | 插件输出参数 JSON Schema                       |
| context_inputs       | object | 插件上下文输入参数 JSON Schema                    |
| forms                | object | 表单配置，包含 renderform 字段                    |
| app                  | object | 应用信息，包含 url、urls、name、code 等字段          |