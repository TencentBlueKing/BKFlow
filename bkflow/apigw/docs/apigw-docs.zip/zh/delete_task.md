### 资源描述

批量删除任务

### 输入通用参数说明
| 参数名称          | 参数类型   | 必须 | 参数说明                                                       |
|---------------|--------|----|------------------------------------------------------------|
| bk_app_code   | string | 是  | 应用ID(app id)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取     |
| bk_app_secret | string | 是  | 安全秘钥(app secret)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取 |


#### 接口参数

| 字段        | 类型    | 必选   | 描述           |
|-----------|-------|------|--------------|
| is_full   | bool  | 否    | 是否删除全部任务     |
| is_mock   | bool  | 否    | 是否删除全部调试任务   |
| task_ids  | list  | 否    | 删除的任务id列表    |

### is_mock 说明
当传参 is_full 时，必须同时传入 is_mock 参数

### 请求参数示例

```json
{
  "bk_app_code": "xxxx",
  "bk_app_secret": "xxxx",
  "bk_username or bk_token": "xxxx",
  "task_ids": [1,2,3]
}
```


### 返回结果示例

```json
{
    "result": true,
    "data": null,
    "message": "success",
    "trace_id": "c8rbc1fas1cb498fa6fb74fc0f884159"
}

```
### 返回结果参数说明

| 字段      | 类型     | 描述                    |
|---------|--------|-----------------------|
| result  | bool   | 返回结果，true为成功，false为失败 |
| message | string | 错误信息                  |
