### 租户访问约束

开启多租户时，全租户应用必须通过 `X-Bk-Tenant-Id` 指定本次请求租户；单租户应用可省略该头，使用 JWT 中已认证的应用租户，显式传入时必须一致。本次请求租户必须与资源所属空间租户一致；同一个全租户应用应在各租户分别创建空间。原有应用与空间/模板绑定仍需满足。若 JWT 包含已认证用户，其租户也必须一致。缺少或不匹配时拒绝请求。

应用态接口不要求额外用户身份。SDK 用户态接口仍要求已认证用户，平台管理员和空间管理员同样不能跨租户。关闭多租户模式时保持单租户行为。

### 资源描述

查看流程快照列表（SDK接口）

### 输入通用参数说明

| 参数名称          | 参数类型   | 必须 | 参数说明                                                       |
|---------------|--------|----|------------------------------------------------------------|
| bk_app_code   | string | 是  | 应用ID(app id)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取     |
| bk_app_secret | string | 是  | 安全秘钥(app secret)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取 |

### HTTP Header 参数说明

| 参数名称         | 参数类型   | 必须 | 参数说明                                                       |
|--------------|--------|----|------------------------------------------------------------|
| BKFLOW-TOKEN | string | 是  | 访问令牌，需要通过 `/space/{space_id}/apply_token/` 接口申请。该 token 用于验证用户对指定空间资源的访问权限（需要提供 template_id 或 task_id） |

### 接口参数

| 字段          | 类型     | 必选 | 描述      |
|-------------|--------|----|---------|
| template_id | string | 是  | 流程ID    |
| version     | string | 否  | 流程快照版本号 |
| operator    | string | 否  | 操作人     |
| desc        | string | 否  | 流程版本描述  |


### 请求参数示例

```
GET /sdk/template/snapshot/list_snapshot/
```

### 返回结果示例

```json
{
     "result": true,
     "data": {
          "count": 3,
          "next": null,
          "previous": null,
          "results": [
               {
                    "id": 123,
                    "create_time": "2025-05-22 11:00:20+0800",
                    "update_time": "2025-05-22 11:00:20+0800",
                    "version": null,
                    "template_id": 1023,
                    "desc": "基于 1.0.0 版本的草稿",
                    "draft": true,
                    "creator": "xxx",
                    "operator": "xxx",
                    "md5sum": "18ce84fe15xlt0075edc4413a9f5575b"
               }
          ]
     },
     "message": "",
     "code": "0"
}
```

### 返回结果参数说明

| 字段      | 类型     | 描述                    |
|---------|--------|-----------------------|
| result  | bool   | 返回结果，true为成功，false为失败 |
| code    | string | 返回码，0表示成功，其他值表示失败     |
| message | string | 错误信息                  |
| data    | dict   | 返回数据                  |

#### data 字段说明

| 字段      | 类型       | 描述       |
|---------|----------|----------|
| count   | int      | 分页返回数据总数 |
| results | list     | 返回数据     |


#### data[results] 字段说明

| 字段          | 类型     | 描述              |
|-------------|--------|-----------------|
| id          | int    | 快照id            |
| create_time | string | 数据创建时间          |
| update_time | string | 数据更新时间          |
| version     | string | 流程版本号（草稿版本无版本号） |
| template_id | string | 关联的模板id         |
| desc        | string | 流程版本描述          |
| draft       | bool   | 是否是草稿版本         |
| creator     | string | 创建人             |
| operator    | string | 操作人             |
| md5sum      | string | 流程数据的md5值       |
