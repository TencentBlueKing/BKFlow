### 资源描述

变量引用统计（SDK接口）

### 输入通用参数说明

| 参数名称          | 参数类型   | 必须 | 参数说明                                                       |
|---------------|--------|----|------------------------------------------------------------|
| bk_app_code   | string | 是  | 应用ID(app id)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取     |
| bk_app_secret | string | 是  | 安全秘钥(app secret)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取 |

### HTTP Header 参数说明

| 参数名称          | 参数类型   | 必须 | 参数说明                                                       |
|---------------|--------|----|------------------------------------------------------------|
| HTTP_BKFLOW_TOKEN | string | 是  | 访问令牌，需要通过 `/space/{space_id}/apply_token/` 接口申请。该 token 用于验证用户对指定空间的访问权限 |

### 接口参数

| 字段          | 类型   | 必选  | 描述          |
|-------------|------|-----|-------------|
| constants   | dict | 是   | 流程中定义的全局变量  |
| activities  | dict | 是   | 流程中的活动节点    |
| gateways    | dict | 是   | 流程中的网关节点    |

### 请求参数示例

```json
{
    "bk_app_code": "xxxx",
    "bk_app_secret": "xxxx",
    "bk_username or bk_token": "xxxx",
    "constants": {
        "var1": {
            "key": "var1",
            "name": "变量1",
            "value": "value1"
        }
    },
    "activities": {},
    "gateways": {}
}
```

### 返回结果示例

```json
{
     "result": true,
     "data": {
          "defined": {
               "var1": {
                    "activities": ["node1", "node2"],
                    "conditions": [],
                    "constants": []
               }
          },
          "nodefined": {
               "${undefined_var}": {
                    "activities": ["node3"],
                    "conditions": [],
                    "constants": []
               }
          }
     },
     "code": "0",
     "message": ""
}
```

### 返回结果参数说明


| 字段      | 类型     | 描述                    |
|---------|--------|-----------------------|
| result  | bool   | 返回结果，true为成功，false为失败 |
| code    | string | 返回码，0表示成功，其他值表示失败     |
| message | string | 错误信息                  |
| data    | dict   | 返回数据                  |

#### data 字段说明

| 字段       | 类型   | 描述                    |
|----------|------|-----------------------|
| defined  | dict | 已定义的变量及其引用位置          |
| nodefined | dict | 未定义的变量及其引用位置          |

#### defined[node_key] 和 nodefined[node_key] 字段说明

| 字段        | 类型     | 描述                    |
|-----------|--------|-----------------------|
| activities | list | 引用该变量的活动节点ID列表        |
| conditions | list | 引用该变量的条件节点ID列表        |
| constants  | list | 引用该变量的其他常量ID列表        |


