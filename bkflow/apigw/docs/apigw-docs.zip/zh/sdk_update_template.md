### 租户访问约束

开启多租户时，全租户应用必须通过 `X-Bk-Tenant-Id` 指定本次请求租户；单租户应用可省略该头，使用 JWT 中已认证的应用租户，显式传入时必须一致。本次请求租户必须与资源所属空间租户一致；同一个全租户应用应在各租户分别创建空间。原有应用与空间/模板绑定仍需满足。若 JWT 包含已认证用户，其租户也必须一致。缺少或不匹配时拒绝请求。

应用态接口不要求额外用户身份。SDK 用户态接口仍要求已认证用户，平台管理员和空间管理员同样不能跨租户。关闭多租户模式时保持单租户行为。

### 资源描述

保存流程（SDK接口）

### 输入通用参数说明

| 参数名称          | 参数类型   | 必须 | 参数说明                                                       |
|---------------|--------|----|------------------------------------------------------------|
| bk_app_code   | string | 是  | 应用ID(app id)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取     |
| bk_app_secret | string | 是  | 安全秘钥(app secret)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取 |

### HTTP Header 参数说明

| 参数名称         | 参数类型   | 必须 | 参数说明                                                       |
|--------------|--------|----|------------------------------------------------------------|
| BKFLOW-TOKEN | string | 是  | 访问令牌，需要通过 `/space/{space_id}/apply_token/` 接口申请。该 token 用于验证用户对指定模板的编辑权限 |

### 路径参数

| 字段         | 类型     | 必选 | 描述    |
|------------|--------|----|-------|
| template_id | string | 是  | 流程模板ID |

### 接口参数

| 字段            | 类型     | 必选 | 描述               |
|---------------|--------|----|------------------|
| name          | string | 是  | 模板名称             |
| operator      | string | 否  | 更新人              |
| notify_config | json   | 否  | 通知配置             |
| desc          | string | 否  | 模板描述             |
| scope_type    | string | 否  | 模板范围类型           |
| scope_value   | string | 否  | 模板范围值            |
| source        | string | 否  | 模板来源(空间接入方自定义字段) |
| version       | string | 否  | 模板版本(空间接入方自定义字段) |
| extra_info    | dict   | 否  | 模板额外信息           |
| pipeline_tree | dict   | 是  | 流程树              |
| triggers      | list   | 是  | 流程触发器            |

### notify_config 示例

```json
{
  "notify_type": {
    "success": ["weixin", "wecom_robot", "sms"],
    "fail": ["mail", "voice", "weixin", "wecom_robot"]
  },
  "notify_receivers": {
    "receiver_group": [],
    "more_receiver": ""
  }
}
```

### 请求参数示例

```json
{
    "bk_app_code": "xxxx",
    "bk_app_secret": "xxxx",
    "bk_username or bk_token": "xxxx",
    "name": "更新后的模板名",
    "desc": "更新后的描述",
    "pipeline_tree": {
        "id": "pd0980c284042448380d29e046bf348fc",
        "start_event": {
            "incoming": "",
            "outgoing": "f22d707b4e7704868b51fbc504107da27",
            "type": "EmptyStartEvent",
            "id": "e39ce14ef5df644ccaa5236b50a9c44ca",
            "name": null
        },
        "end_event": {
            "incoming": [
                "f520808740b9945f8b01fa1dd889945d9"
            ],
            "outgoing": "",
            "type": "EmptyEndEvent",
            "id": "e17aef95ed6934a428215b2a7a3fa4184",
            "name": null
        },
        "activities": {
            "e36e8026b07b5448299b52f91a9d265af": {
                "incoming": [
                    "f22d707b4e7704868b51fbc504107da27"
                ],
                "outgoing": "f520808740b9945f8b01fa1dd889945d9",
                "type": "ServiceActivity",
                "id": "e36e8026b07b5448299b52f91a9d265af",
                "name": null,
                "error_ignorable": false,
                "timeout": null,
                "skippable": true,
                "retryable": true,
                "component": {
                    "code": "example_component",
                    "inputs": {}
                },
                "optional": false
            }
        },
        "gateways": {},
        "flows": {
            "f22d707b4e7704868b51fbc504107da27": {
                "is_default": false,
                "source": "e39ce14ef5df644ccaa5236b50a9c44ca",
                "target": "e36e8026b07b5448299b52f91a9d265af",
                "id": "f22d707b4e7704868b51fbc504107da27"
            },
            "f520808740b9945f8b01fa1dd889945d9": {
                "is_default": false,
                "source": "e36e8026b07b5448299b52f91a9d265af",
                "target": "e17aef95ed6934a428215b2a7a3fa4184",
                "id": "f520808740b9945f8b01fa1dd889945d9"
            }
        }
    },
    "triggers": []
}
```

### 返回结果示例

```json
{
    "result": true,
    "data": {
        "id": 4,
        "space_id": 2,
        "name": "更新后的模板名",
        "desc": "更新后的描述",
        "notify_config": {},
        "scope_type": null,
        "scope_value": null,
        "pipeline_tree": {},
        "source": null,
        "version": "",
        "is_enabled": true,
        "extra_info": {}
    },
    "message": "",
    "code": "0"
}
```

### 返回结果参数说明

| 字段      | 类型     | 描述                    |
|---------|--------|-----------------------|
| result  | bool   | 返回结果，true为成功，false为失败 |
| code    | string | 返回码，0表示成功，其他值表示失败     |
| message | string | 错误信息                  |
| data    | dict   | 返回数据                  |

#### data 字段说明

| 字段            | 类型     | 描述       |
|---------------|--------|----------|
| id            | int    | 流程ID     |
| space_id      | int    | 流程所属空间ID |
| name          | string | 流程名称     |
| desc          | string | 流程描述     |
| notify_config | dict   | 通知配置     |
| scope_type    | string | 流程范围类型   |
| scope_value   | string | 流程范围ID   |
| pipeline_tree | dict   | 流程树详情    |
| source        | string | 流程来源     |
| version       | string | 流程版本     |
| is_enabled    | bool   | 流程是否启用   |
| extra_info    | dict   | 流程扩展信息   |



### 定时触发器时区

`triggers[].config.timezone` 可指定有效的 IANA 时区（例如 `Europe/Paris`）。新建时省略则保存当前请求的有效用户时区；编辑时省略则保留既有计划时区。历史未标时区的计划继续使用其已保存的 Engine 调度时区，不随编辑者切换。返回的 config 保留新计划的 timezone，界面按此显示和预览。
