### 资源描述

获取流程变量类型（SDK接口）

### 输入通用参数说明

| 参数名称          | 参数类型   | 必须 | 参数说明                                                       |
|---------------|--------|----|------------------------------------------------------------|
| bk_app_code   | string | 是  | 应用ID(app id)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取     |
| bk_app_secret | string | 是  | 安全秘钥(app secret)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取 |

### 权限说明

该接口使用默认权限，**不需要 BKFLOW-TOKEN**。

### 接口参数

无

### 请求参数示例

```
GET /sdk/template/variable/
```

### 返回结果示例

```json
{
     "result": true,
     "data": [
          {
               "code": "input",
               "name": "输入",
               "description": "输入变量",
               "form": "",
               "meta_tag": "",
               "tag": "",
               "type": "input"
          },
          {
               "code": "output",
               "name": "输出",
               "description": "输出变量",
               "form": "",
               "meta_tag": "",
               "tag": "",
               "type": "output"
          }
     ],
     "message": "",
     "code": "0"
}
```

### 返回结果参数说明

| 字段      | 类型     | 描述                    |
|---------|--------|-----------------------|
| result  | bool   | 返回结果，true为成功，false为失败 |
| code    | string | 返回码，0表示成功，其他值表示失败     |
| message | string | 错误信息                  |
| data    | list   | 返回数据，变量类型列表            |

#### data[item] 字段说明

| 字段           | 类型        | 描述         |
|--------------|-----------|------------|
| code         | string    | 变量类型代码     |
| name         | string    | 变量类型名称     |
| description  | string    | 变量描述       |
| form         | string    | 表单路径       |
| meta_tag     | string    | 变量meta_tag |
| tag          | string    | 变量tag      |
| type         | string    | 变量类型       |

